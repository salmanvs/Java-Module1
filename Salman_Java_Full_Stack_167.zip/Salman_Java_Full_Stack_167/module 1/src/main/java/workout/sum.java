package workout;

public class sum {
	public static void main(String[] args) {
		int sum=0;
		for (int i = 100; i <= 200; i++) {
			if (i%7==0) {
			sum = sum + i;}
		}
		System.out.println("Sum of First 10 Natural Numbers is = " + sum);
	}

}
