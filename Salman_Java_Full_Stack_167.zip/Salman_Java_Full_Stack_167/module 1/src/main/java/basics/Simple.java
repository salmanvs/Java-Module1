package basics;

 public class Simple{
	 public static void main(String[] args) {
		 
		 int b=11;
		 float a=10.4f;
		 
		System.out.println("hai");
		 System.out.println(b);
		 System.out.println(a);
	}
 }
