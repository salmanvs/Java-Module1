package basics;

public class Employee {
public static void main(String[] args) {
	//How to create a variable
	int a=1089898989;// datatype variablename=value;
	byte b=127;
	
short f=8999;
double d1=568766787;
float f1=566858758576876769889085766768.565f;
long l2=5786787980990895786l;
String n="dgfhggggggggggggf";
char c1='d';
	

int o=1234555469;
short p=12329;
long l=8768776865657676599l;
double y=432342432;
char w='d';
String g="hgsdfhagsf";
byte j=123;
float i=3123423424322.13342342343422f;


	System.out.println("*********Employee Class*********");
}
}
