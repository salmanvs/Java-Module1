package basics;

public class s1 {
	public static void main(String[] args) {
		System.out.println(34);
	}

}
