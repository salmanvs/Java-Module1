package opertors;

public class example1 {
	public static void main(String[] args) {
		int x=10;
		System.out.println(++x);
		System.out.println(--x);
		System.out.println(x--);
		System.out.println(x++);
		System.out.println(x++);
				
	}

}
