package opertors;

public class example3 {
	public static void main(String[] args) {
		boolean a=true; 
		boolean b=false;
		System.out.println(!a);
		System.out.println(!b);		
	}

}
