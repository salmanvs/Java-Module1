package OOPs;

public class TestStudent {
	public static void main(String[] args) {
		//classname objectname=new classname();
		Student s1=new Student();
		s1.disply();
		System.out.println(s1.name);
		//reference variable
		s1.name="sgfhg";
		s1.insert(9, "fghygjh");
		s1.disply();
		
		
		
	}
}
