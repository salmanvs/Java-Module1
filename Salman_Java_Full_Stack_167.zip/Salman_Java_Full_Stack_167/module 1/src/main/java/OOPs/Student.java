package OOPs;

public class Student {
	int rollno;// instance
	static String name;// static

	public void disply() {
		int a;// local
		System.out.println("name " + name + " Id " + rollno);
	}
	//using methods
	void insert(int r,String n)
	{
		rollno=r;
		name=n;
	}

}
