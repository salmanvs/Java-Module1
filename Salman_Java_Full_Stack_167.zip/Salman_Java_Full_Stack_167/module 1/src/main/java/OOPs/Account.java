package OOPs;

public class Account {
	int acc_no;
	String name;
	float amount;
	void insert(int a,String b,float c) {
		acc_no=a;
		name=b;
		amount=c;
	}void deposit(float c){
		amount=amount+c;
		System.out.println(c+"deposited");
		
	}void withdraw(float c){
		if(amount<c) {
			System.out.println("insufficient fund");
		}else {
			amount=amount-c;
			System.out.println(c+"withdrawed");
		}
	}void checkbalance(){
		System.out.println(amount+"balance");
	}
	@Override
	public String toString() {
		return "Account [acc_no=" + acc_no + ", name=" + name + ", amount=" + amount + "]";
	}

}
