package OOPs;

public class Testemployee {
	public static void main(String[] args) {
		// creating object for employee
		Emplyoee e1 = new Emplyoee();
		// calling display method by e1 object
//		e1.disply();
		// initializing values of e1 object through method
		e1.insert("sds", 2);
		// calling display method by e1 object

		e1.disply();
		// priniting value of e1 object

		System.out.println(e1);
		// creating object for employee e2

		Emplyoee e2 = new Emplyoee();
		// initializing values of e2 object through reference variable

		e2.name = "das";
		e2.employeeID = 21;
		// priniting value of e2 object

		System.out.println(e2);
		// calling display method by e2 object

		e2.disply();
		// calling toString method by e2 object

		e2.toString();
		// priniting value of e1 object from toString method

		System.out.println(e2.toString());

	}

}
