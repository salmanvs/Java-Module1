package OOPs;

public class TestStudent2 {
	public static void main(String[] args) {
		Student2 s1 = new Student2();
		s1.insert("das" + "", 121);
		s1.disply();
		s1.toString();
		System.out.println(s1.toString());
		System.out.println();
		s1.insert("dew", 110);
		s1.disply();
		s1.toString();
		System.out.println(s1.toString());
	}

}
