package OOPs;

public class TestAccount {
	public static void main(String[] args) {
		Account x=new Account();
		x.insert(12132, "asdas", 0);
		x.checkbalance();
		
		x.deposit(1000);
		x.checkbalance();
	
		x.withdraw(900);
		x.checkbalance();
		//x.toString();
		System.out.println(x);
	}

}
