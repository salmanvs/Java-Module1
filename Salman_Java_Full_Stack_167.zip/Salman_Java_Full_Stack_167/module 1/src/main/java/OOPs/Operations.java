package OOPs;

public class Operations {
	//method overriding
	//changeing no of arguments

	void add(int a, int b) {
		System.out.println(a + b);
	}

	void add(int a, int b, int c) {
		System.out.println(a + b + c);
	}

	int add(int a, int b, int c, int d) {

		return a + b + c + d;
	}

	static int subtract(int a, int b) {
		return a - b;
	}

	static void divide(int a, int b) {
		System.out.println(a / b);

	}

	static int multiplication(int a, int b) {
		return a * b;

	}

	static void modulus(int a, int b) {
		System.out.println(a % b);

	}

	public static void main(String[] args) {

		Operations o1 = new Operations();
		o1.add(12, 10);
		System.out.println(o1.add(1, 2, 3, 4));
		System.out.println(subtract(50, 20));
		divide(10, 2);
		System.out.println(multiplication(2, 2));
		modulus(80, 13);
	}
}
