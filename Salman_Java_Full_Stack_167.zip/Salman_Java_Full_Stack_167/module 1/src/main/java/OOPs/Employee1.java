package OOPs;

public class Employee1 {
	int no;
	String name;
	float salary;
	void insert(int x,String y,float z) {
		no=x;
		name=y;
		salary=z;
		System.out.println(no+" "+name+" "+salary);

	}
	void disply() {
		System.out.println(no+" "+name+" "+salary);
	}
	@Override
	public String toString() {
		return "Employee1 [no=" + no + ", name=" + name + ", salary=" + salary + "]";
	}

}
