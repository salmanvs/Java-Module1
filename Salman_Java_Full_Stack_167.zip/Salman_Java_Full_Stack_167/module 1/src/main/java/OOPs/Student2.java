package OOPs;

public class Student2 {
	String name;
	int id;
	void insert(String r,int n) {
		name=r;
		id=n;
	}
	void disply() {
		System.out.println(name+" "+id);
	}
	@Override
	public String toString() {
		return "Student2 [name=" + name + ", id=" + id + "]";
	}

}
