package assignment1;

public class q10 {
	public static void main(String[] args) {
		float a=4.0f;
		float b=1.0f;
		int c=1;
		int z=3;
		int d=5;
		int e=7;
		int f=9;
		int g=11;
		System.out.println(a*(c-(b/z)+(b/d)-(b/e)+(b/f)-(b/g)));
		System.out.println(4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11)));
	}

}
