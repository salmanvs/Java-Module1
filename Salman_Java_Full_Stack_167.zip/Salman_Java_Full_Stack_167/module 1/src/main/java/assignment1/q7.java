package assignment1;

import java.util.Scanner;

public class q7 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("input first number");
		int n1=s.nextInt();
		for(int i=1;i<=10;i++)
		{
			System.out.println(i+"*"+n1+"="+(i*n1));
		}
		
		
//		System.out.println("m1");
//		int n2=s.nextInt();
//		System.out.println("m2");
//		int n3=s.nextInt();
//		System.out.println("m3");
//		int n4=s.nextInt();
//		System.out.println("m4");
//		int n5=s.nextInt();
//		System.out.println("m5");
//		int n6=s.nextInt();
//		System.out.println(n1+"X"+n2+"="+(n1*n2));
//		System.out.println(n1+"X"+n3+"="+(n1*n3));
//		System.out.println(n1+"X"+n4+"="+(n1*n4));
//		System.out.println(n1+"X"+n5+"="+(n1*n5));
//		System.out.println(n1+"X"+n6+"="+(n1*n6));
		
	}

}
