package assignment1;

import java.util.Scanner;

public class q5 {
	public static void main(String[] args) {

		/*
		 * Scanner s=new Scanner(System.in); 
		 * System.out.print("Input first number:");
		 * int n1=s.nextInt();
		 *  System.out.print("Input second number:"); int
		 * n2=s.nextInt();
		 *  System.out.println(n1+"X"+n2+"="+(n1*n2));
		 */
Scanner s=new Scanner(System.in);
System.out.println("input first number");
int n1=s.nextInt();
System.out.println("input second number");
int n2=s.nextInt();
System.out.println(n1+"X"+n2+"="+(n1*n2));
	}

}
