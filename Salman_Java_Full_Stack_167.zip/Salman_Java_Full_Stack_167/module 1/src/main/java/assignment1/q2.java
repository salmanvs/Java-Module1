package assignment1;

public class q2 {
	public static void main(String[] args) {
		System.out.println(74+36
				);
	}

}
