package SwitchEgs;

public class Eg3 {
	public static void main(String[] args) {
		int year = 2;
		char division = 'B';
		switch (year) {
		case 1 :
			switch (division) {
			case 'A':
				System.out.println("malayalam medium");
				break;
			case 'B':
				System.out.println("english medium");
				break;
			}
		case 2 :
			switch (division) {
			case 'A':
				System.out.println("arabic medium");
				break;
			case 'B':
				System.out.println("hindi medium");
				break;
			}break;
		}

	}
}