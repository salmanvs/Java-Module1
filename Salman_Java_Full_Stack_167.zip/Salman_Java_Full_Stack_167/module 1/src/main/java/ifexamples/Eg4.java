package ifexamples;

public class Eg4 {
	public static void main(String[] args) {
		int mark = 72;

		if (mark>=0&&mark<=23) {
			System.out.println("fail");
		} else if (mark >= 24 && mark < 40) {
			System.out.println("C grade");

		}else if(mark>=40&&mark<56) {
			System.out.println("B grade");
		}else if(mark>=56&&mark<72) {
			System.out.println("A grade");
		}else if(mark>=72&&mark<=80) {
			System.out.println("A+ grade");
		}else {
			System.out.println("INVALID");
		}

	}
}
