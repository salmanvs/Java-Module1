package ifexamples;

public class Eg6 {
	public static void main(String[] args) {
		int a=101;
		if(a>=0&&a<=100) {
			if(a>63) {
				System.out.println("eligible for higher studies");
			}else if(a<=63) {
				System.out.println("not eligible for higher studies");
			}
				
		}else {
			System.out.println("invalid mark");
		}
	}
}	