package ifexamples;

public class Eg5 {
	public static void main(String[] args) {
		int a=0;
		if (a<0) {
			System.out.println("negative");
		}else if (a>0) {
			System.out.println("positive");
		}else {
			System.out.println("invalid");
		}
	}

}
