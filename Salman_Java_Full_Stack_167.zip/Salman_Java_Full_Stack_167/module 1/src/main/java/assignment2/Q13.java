package assignment2;

import java.util.Scanner;

public class Q13 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("x =");
		int x = s.nextInt();
		System.out.print("y =");
		int y = s.nextInt();
		System.out.println("before swap");
		System.out.println("x = " + x +" y = " + y);
		System.out.println("after swap");
		x=(x*y);
		y=x/y;
		
		x=x/y;
		System.out.println("x = " + x +" y = " + y);
	}

}
