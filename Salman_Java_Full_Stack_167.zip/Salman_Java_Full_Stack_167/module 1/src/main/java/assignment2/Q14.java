package assignment2;

import java.util.Scanner;

public class Q14 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.print("days =");
		int days =s.nextInt();
		System.out.print("months =");
		System.out.println(days/30);
		System.out.print("days =");
		System.out.println(days%30);
	}

}
