package assignment2;

import java.util.Scanner;

public class Q11 {
	public static void main(String[] args) {
		int sum =0;
		Scanner s = new Scanner(System.in);
		System.out.println("a");
		int a=s.nextInt();
		System.out.println("b");
		int b=s.nextInt();
		
		for(int i=a;i<=b;i++) {
			if(i%7==0) {
				sum = sum + i;
			}
		}System.out.println();
		System.out.println("sum="+sum);
	}
}
