package AssignmentsonString;

import java.util.Scanner;

public class Q6 {
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("A");
		int A=s.nextInt();
		System.out.println("B");
		int B=s.nextInt();
		if(A!=B) {
			if(A>B) {System.out.println("A is larger than B");
			System.out.print(" ");
			System.out.println(A+">"+B);
				
			}
		}
		else {
			System.out.println("A equals B");
			System.out.print("  ");
			System.out.println(A+"="+B);
		}

	
	
	}
}
