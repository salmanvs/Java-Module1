package AssignmentsonString;

import java.util.Scanner;

public class Q7 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("a");
		int a= s.nextInt();
		System.out.println("b");
		int b=s.nextInt();
		System.out.println("c");
		int c=s.nextInt();
		System.out.println("sum"+"="+(a+b+c));
		System.out.println("average"+"="+((a+b+c)/3));
		System.out.println("product"+"="+(a*b*c));
		int larger=(a>b)?((a>c)?a:c):((b>c)?b:c);
		System.out.println("greatest number"+" "+"="+larger);
	}
}