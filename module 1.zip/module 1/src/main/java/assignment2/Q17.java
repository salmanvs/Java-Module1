package assignment2;

public class Q17 {
	public static void main(String[] args) {
	}

}
