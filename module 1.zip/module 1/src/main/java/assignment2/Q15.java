package assignment2;

public class Q15 {

}
