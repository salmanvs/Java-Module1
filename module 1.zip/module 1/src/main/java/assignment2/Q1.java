package assignment2;

public class Q1 {
	public static void main(String[] args) {
		int a=11;
		if(a%2==0) {
			System.out.println("even number");
		}else {
			System.out.println("odd number");
		}
		
	}

}
