package assignment2;

public class Q2 {
	public static void main(String[] args) {
		int i=10;
		int j=20;
        if(i<j) {
        	System.out.println("i smaller than j");
        }else if(i==j) {
        	System.out.println("i equals j");
        	
        }else if(i>=j) {
        	System.out.println("i greater than j");
        }
	}

}
