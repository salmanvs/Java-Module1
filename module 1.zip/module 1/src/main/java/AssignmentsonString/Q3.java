package AssignmentsonString;

public class Q3 {
	public static void main(String[] args) {
		int Fahrenheit=257;
		System.out.println("celcius"+"="+((Fahrenheit-32)*5)/9);
	}

}
