package AssignmentsonString;

public class Q8 {
	public static void main(String[] args) {
		int a=10;
		int b=2;
		int c=0;
		if(a%b==0) {
			int check=(a%b==0)?(a*b):c;
		System.out.println(check);
			
		}
			
	}

}
