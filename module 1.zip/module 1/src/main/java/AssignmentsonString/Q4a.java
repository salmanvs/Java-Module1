package AssignmentsonString;

public class Q4a {
	public static void main(String[] args) {
		
		System.out.println("1"+" "+"2"+" "+"3"+" "+"4");
	}

}
