package AssignmentsonString;

public class Q5 {
	public static void main(String[] args) {
		int a=4;
		int b=5;
		System.out.println("sum"+"="+(a+b));
		System.out.println("product"+"="+(a*b));
		System.out.println("difference"+"="+(a-b));
		System.out.println("division"+"="+(a/b));
		
		
	}

}
