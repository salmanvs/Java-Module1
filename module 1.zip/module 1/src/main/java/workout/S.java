package workout;

import java.util.Scanner;

public class S {
	public static void main(String[] args) {
		int i = 1;
		System.out.println("odd numbers");
		while (i <= 10) {
			System.out.println(i);
			i = i++;
			if (i == 7) {
				continue;
			}
		}
	}
}
