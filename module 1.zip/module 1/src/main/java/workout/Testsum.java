package workout;

public class Testsum {
public static void main(String[] args) {
	Sum s=new Sum(10, 20),s1=new Sum(25, 2500);
	s.disply();s1.disply();
}
}
