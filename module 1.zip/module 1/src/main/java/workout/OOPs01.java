package workout;

public class OOPs01 {//class,super class,parent class
	int rollno;//instance
	String name;  //instance
	static String college="KEC";//static
	void change() {
		college="Maharajas";//local
	}
	OOPs01(int rollno,String name) {//subclass
		this.rollno=rollno;//local
		this.name=name;//local
	}
	void disply() {
		System.out.println(rollno+" "+name+" "+college);
	}
}
