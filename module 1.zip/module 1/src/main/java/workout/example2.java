package workout;

public class example2 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		if (a < b) {

			if (a > b) {
				System.out.println("a not equals b also less than ");
			}

			
			if (a > b) {
				System.out.println("a not eqals b also greater than");
			}
			
		}
		else {
			System.out.println("k");
		}
	}
}