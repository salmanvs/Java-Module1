package workout;

public class Room {
	float height;
	float width;
	float breadth;

	Room(float height, float width, float breadth) {
		this.height = height;
		this.width = width;
		this.breadth = breadth;}
		
		void volume() {
			System.out.println(height*width*breadth+" cubicmeter");
	}
}
