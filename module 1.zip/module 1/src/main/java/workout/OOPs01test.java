package workout;

public class OOPs01test {
	public static void main(String[] args) {
		OOPs01 s=new OOPs01(19010,"kiran");
		s.disply();
		OOPs01 s1=new OOPs01(19001,"Arun");
		s1.change();
		
		s1.disply();
	}
}
