package workout;

public class TestStudend {
	public static void main(String[] args) {
		Student s, s2;
		s = new Student("arun", 45, 60, 54);
		s2 = new Student("Manu", 60, 62, 54);
		s.details();
		s.average();
		System.out.println();
		s2.details();
		s2.average();
	}

}