package workout;

public class TestRoom {
	public static void main(String[] args) {
		Room r=new Room(25.3f, 25.3f, 56.7f);
		r.volume();
	}

}
