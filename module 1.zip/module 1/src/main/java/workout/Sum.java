package workout;

public class Sum {
	int a,b;
	Sum(int a,int b){
		this.a=a;
		this.b=b;}
		void disply() {
			System.out.println(a+b);
		
	}
}
