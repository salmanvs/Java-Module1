package workout;

public class Student {
	String name;
	int maths;
	int english;
	int science;

	Student(String name, int m, int e, int s) {
		this.name = name;
		maths = m;
		english = e;
		science = s;
	}

	void details() {
		System.out.println("Name of the student : " + name);
		System.out.println("marks gained on maths " + "=" + maths);
		System.out.println("marks gained on english " + "=" + english);
		System.out.println("marks gained on science " + "=" + science);
	}

	void average() {
		System.out.println("average mark = " + (maths + english + science) / 3);

	}
}