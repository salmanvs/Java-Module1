package superExamples;

public class Animal2 {
	Animal2() {
		System.out.println("white colour");
	}

}
