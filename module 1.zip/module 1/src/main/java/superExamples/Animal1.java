package superExamples;

public class Animal1 {
	void colour() {
		System.out.println("black colour");
	}

}
