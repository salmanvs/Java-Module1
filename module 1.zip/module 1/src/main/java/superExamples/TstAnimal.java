package superExamples;

public class TstAnimal {
	public static void main(String[] args) {
		Dog d=new Dog();
		d.disply();
	}

}
