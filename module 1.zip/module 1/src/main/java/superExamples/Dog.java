package superExamples;

public class Dog extends Animal{
	String colour="Black";
	
	void disply() {
		System.out.println(colour);
		System.out.println(super.colour);
	}

}
