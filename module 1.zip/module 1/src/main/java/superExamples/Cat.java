package superExamples;

public class Cat extends Animal1{
void colour() {
	System.out.println("white colour");
	
		
	}void merge(){
		super.colour();
}
}
