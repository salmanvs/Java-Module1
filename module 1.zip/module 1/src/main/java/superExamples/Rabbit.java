package superExamples;

public class Rabbit extends Animal2{
	Rabbit(){
		super();
		System.out.println("black dot");
		}
	}
	


