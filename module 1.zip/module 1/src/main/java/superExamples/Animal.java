package superExamples;

public class Animal {
	String colour="white";

}
