package superExamples;

public class TextAnimal2 {
	public static void main(String[] args) {
		Rabbit r=new Rabbit();
	}

}
