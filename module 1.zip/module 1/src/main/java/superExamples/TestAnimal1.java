package superExamples;

public class TestAnimal1 {
	public static void main(String[] args) {
		Cat c=new Cat();
		c.colour();
		c.merge();
	}

}
