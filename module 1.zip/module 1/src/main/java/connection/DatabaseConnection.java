package connection;

import java.sql.*;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;

public class DatabaseConnection {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://192.168.18.245:3306/javadb_167", "javadb_167",
					"ben#u62000");
			Statement smt = con.createStatement();
			ResultSet rs = smt.executeQuery("select * from Emp3");
			while (rs.next()) {
				System.out.println(rs.getInt("id") + " " + rs.getString("name") + " " + rs.getFloat(3));
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}