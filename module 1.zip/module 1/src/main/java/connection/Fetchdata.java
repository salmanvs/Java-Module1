package connection;

import java.sql.*;
import java.util.Scanner;

public class Fetchdata {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("choose your operation:insert or update or delete or printrow or getrecord or printrow1");
		String query = s.nextLine();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://192.168.18.245:3306/javadb_167", "javadb_167",
					"ben#u62000");
			Statement smt = con.createStatement();
			ResultSet rs = smt.executeQuery("select * from Emp3");

			switch (query) {
			case "insert": {
				int result = smt.executeUpdate("insert into Emp3 values(106,'saanu',16000)");
				System.out.println("inserted");
				break;
			}
			case "update": {
				int result = smt.executeUpdate("update Emp3 set name='arun',salary=13000 where id=102");
				System.out.println("updated");
				break;
			}
			case "delete": {
				int result = smt.executeUpdate("delete from Emp3 where  id=106 ");
				System.out.println("Deleted");
				break;
			}
			case "printrow": {
				System.out.println("Enter row number");
				int row = s.nextInt();
				rs.absolute(row);
				System.out.println(rs.getInt("id") + " " + rs.getString("name") + " " + rs.getFloat("salary"));

				break;
			}
			case "getrecord": {
				while (rs.next()) {
					System.out.println(rs.getInt("id") + " " + rs.getString("name") + " " + rs.getFloat("salary"));
				}

				break;
			}
			case "printrow1": {
				System.out.println("Enter row number");
				int row = s.nextInt();
				rs.relative(row);
				System.out.println(rs.getInt("id") + " " + rs.getString("name") + " " + rs.getFloat("salary"));

				break;

			}}
			con.close();
		
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}

}
