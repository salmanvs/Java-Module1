package connection;

import java.sql.*;
import java.util.Scanner;

public class StoreData {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter I or U or R or D");
		String value = s.nextLine();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection com = DriverManager.getConnection("jdbc:mysql://192.168.18.245:3306/javadb_167", "javadb_167",
					"ben#u62000");

			switch (value) {
			case "I": {
				System.out.println("Enter id :");
				int id = Integer.parseInt(s.nextLine());
				System.out.println("Enter name :");
				String name = s.nextLine();
				System.out.println("Enter salary :");
				float salary = Float.parseFloat(s.nextLine());
				PreparedStatement smt = com.prepareStatement("insert into Emp3 values(?,?,?)");
				smt.setInt(1, id);
				smt.setString(2, name);
				smt.setFloat(3, salary);

				int i = smt.executeUpdate();
				System.out.println(i + "records inserted");
				break;
			}
			case "U": {
				System.out.println("Enter id :");
				int id = Integer.parseInt(s.nextLine());
				System.out.println("Enter name :");
				String name = s.nextLine();
				System.out.println("Enter salary :");
				float salary = Float.parseFloat(s.nextLine());
				PreparedStatement smt = com.prepareStatement("update Emp3 set name=?, salary=? where id=?");
				smt.setString(1, name);
				smt.setFloat(2, salary);
				smt.setInt(3, id);

				int i = smt.executeUpdate();
				System.out.println(i + "records updated");
				break;
			}
			case "R": {
				PreparedStatement smt = com.prepareStatement("select * from Emp3");
				ResultSet rs = smt.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getFloat(3));
				}

				break;
			}

			case "D": {
				System.out.println("Enter id :");
				int id = Integer.parseInt(s.nextLine());
				PreparedStatement smt = com.prepareStatement("delete from Emp3 where id=?");
				smt.setInt(1, id);
				int i = smt.executeUpdate();
				System.out.println(i + "records deleted");
				break;
			}
			default:
				break;
			}

			com.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
