package oops;

public class Account {
	int id;
	String name;
	int balance=0;
	
	public Account(int id,String name) {
		this.id=id;
		this.name=name;
	}public Account(int id,String name,int balance){
		this.id=id;
		this.name=name;
		this.balance=balance;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getBalance() {
		return balance;
	}
	public int credit(int amount) {
		balance=balance+amount;
		return balance;
	}
	public int debit(int amount) {
		if(amount<=balance) {
			balance=balance-amount;
			
		}else {System.out.println("insufficient balance");
		
		}return balance;
	}
	@Override
	public String toString() {
		return "Account [id=" + id + ", name=" + name + ", balance=" + balance + "]";
	}
	

}
