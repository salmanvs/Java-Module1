package oops;

public class TestDate {
	public static void main(String[] args) {
		Date d=new Date(32, 10, 2022);
		Date d1=new Date();
		d1.setDate(12, 7, 2022);
		System.out.println(d);
		System.out.println(d1);
		
		
		
		
	}

}
