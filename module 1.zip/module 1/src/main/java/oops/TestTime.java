package oops;

public class TestTime {
	public static void main(String[] args) {
		Time t=new Time(5, 40, 50);
        System.out.println(t);
	}

}
