package oops;

public class TestAccount {
	public static void main(String[] args) {
		Account a=new Account(14143, "mayavi");
		System.out.println(a);
		Account b=new Account(14143, "mayavi", 0);
		b.credit(1000);
		b.debit(1001);
		System.out.println(b);
	}

}
