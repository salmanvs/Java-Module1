package array;

import java.util.Iterator;
import java.util.TreeSet;

public class TreesetEg {
	public static void main(String[] args) {
		TreeSet<Integer> i = new TreeSet<Integer>();
		i.add(3);
		i.add(4);
		i.add(1);
		i.add(6);
		i.add(3);

		Iterator<Integer> itr = i.iterator();
		while (itr.hasNext())
//		for(Integer in:i)
//			System.out.println(in);

		{
			System.out.println(itr.next());
		}
	}

}
