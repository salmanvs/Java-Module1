package array;

import java.util.*;
import java.util.Iterator;

public class Hashset {
	public static void main(String[] args) {

		HashSet<String> s = new HashSet<String>();
		s.add("apple");
		s.add("mango");
		s.add("orange");
//		Iterator<String> itr = s.iterator();
//		while (itr.hasNext())
//			System.out.println(itr.next());
		s.add("guava");
//		Iterator<String> itr=s.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
		s.remove("apple");
//		Iterator<String> itr=s.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());

		HashSet<String> s1 = new HashSet<String>();
		s1.add("banana");
		s1.add("grape");

		s.addAll(s1);
//		Iterator<String> itr = s.iterator();
//		while (itr.hasNext()) {
//			System.out.println(itr.next());
		
		s.removeAll(s1);
		Iterator<String> itr=s.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}	
	}
}