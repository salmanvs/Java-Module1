package array;


import java.util.LinkedHashSet;

public class Testlinkedhashset {
	public static void main(String[] args) {
		LinkedHashSet<Linkedhashset> l=new LinkedHashSet<Linkedhashset>();
		
		Linkedhashset s1=new Linkedhashset(101, 1001, "ravi", "business");
		Linkedhashset s2=new Linkedhashset(102, 1002, "manu", "business");
		Linkedhashset s3=new Linkedhashset(103, 1003, "sanu", "business");
		
		l.add(s3);
		l.add(s2);
		l.add(s1);
		
		for(Linkedhashset b:l) {
			System.out.println(b.id+" "+b.rollno+" "+b.name+" "+b.job);
		}
	}

}
