package array;

public class Student {
		int id,rollno;
		String name,department;
		
		Student(int id,int rollno,String name,String department){
			this.department=department;
			this.id=id;
			this.name=name;
			this.rollno=rollno;
		
	}

}
