package array;

public class Linkedhashset {
	int rollno,id;
	String name,job;
	
	Linkedhashset(int rollno,int id,String name,String job){
		this.id=id;
		this.job=job;
		this.name=name;
		this.rollno=rollno;
	}
	

}
