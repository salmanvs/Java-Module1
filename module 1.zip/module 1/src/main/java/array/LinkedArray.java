package array;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedArray {
	public static void main(String[] args) {

		LinkedList<String> list = new LinkedList<String>();
		list.add("manu");
		list.add("karan");
		list.add("arun");
		list.add("varun");

		Iterator<String> it = list.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("    adding keerthi");

		list.add(1, "keerthi");
//		System.out.println(list);
		Iterator<String> its = list.iterator();
		while (its.hasNext()) {
			System.out.println(its.next());
		}
		System.out.println("     adding govind and karthik");
		LinkedList<String> list2 = new LinkedList<String>();
		list2.add("govind");
		list2.add("karthik");
		list2.addAll(list);
		Iterator<String> itsa = list2.iterator();
		while (itsa.hasNext()) {
			System.out.println(itsa.next());
		}
		System.out.println("    deleting keerthi");
		list2.remove("keerthi");
		Iterator<String> itsaa = list2.iterator();
		while (itsaa.hasNext()) {
			System.out.println(itsaa.next());
		}
		System.out.println("    deleting karthik");
		list2.remove(1);
//		Iterator<String> itsaaa=list2.iterator();
//		while(itsaaa.hasNext()) {
//			System.out.println(itsaaa.next());
		Iterator<String> itsaaa = list2.descendingIterator();
		while (itsaaa.hasNext()) {
			System.out.println(itsaaa.next());
		}
		
	}
}
