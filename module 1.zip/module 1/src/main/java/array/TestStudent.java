package array;

import java.util.Iterator;
import java.util.LinkedList;


public class TestStudent {
	public static void main(String[] args) {
		LinkedList<Student> list=new LinkedList<Student>();
		
		Student st1=new Student(101, 12001, "Das", "maths");
		Student st2=new Student(102, 12002, "MA", "maths");
		Student st3=new Student(103, 12003, "Asthamy", "maths");
		Student st4=new Student(104, 12004, "Gopz", "maths");
		
		
		list.add(st1);
		list.add(st2);
		list.add(st3);
		list.add(st4);
		
		Iterator itr=list.iterator();
		while(itr.hasNext()) {
			Student st=(Student)itr.next();
			System.out.println(st.id+" "+st.name+" "+st.rollno+" "+st.department);
		}
	}

}
