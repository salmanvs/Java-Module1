package array;

public class Array1 {
	public static void main(String[] args) {
		//int a[]=new int[5];
		int a[]= {
				10,20,30,40,50
		};
		//System.out.println(a);
		for (int i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
		}
		
		int ab[]= {12,23,34,45};
		
		for(int i:ab)
		{
			System.out.println(i);
		}
		System.out.println("Multi Dimentional Array");
		
		int abc[][]=new int[2][2];
		abc[0][0]=13;
		abc[0][1]=13;
		abc[1][0]=13;
		abc[1][1]=13;
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)

		
		{
			System.out.print(abc[i][j]+" ");
		}
			System.out.println();
		}

		System.out.println();
		
//		for(int i:a)
//		{
//			System.out.println(i);
//		}
	}

}
