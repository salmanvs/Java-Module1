package assignment1;

public class q1 {
	public static void main(String[] args) {
		System.out.println("hello");
		System.out.println("salman");
	}

}
