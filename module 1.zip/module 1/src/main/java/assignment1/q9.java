package assignment1;

public class q9 {
	public static void main(String[] args) {
		float a=25.5f;
		float b=3.5f;
		float c=40.5f;
		float d=4.5f;
		System.out.println((a*b-b*b)/(c-d));
	}

}
