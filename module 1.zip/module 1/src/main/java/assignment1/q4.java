package assignment1;

public class q4 {
	public static void main(String[] args) {
		System.out.println(-5+6*8);
		System.out.println((50+9)%9);
		System.out.println(20+-3*5/8);
		System.out.println(5+15/3*2-8%3);
	}

}
