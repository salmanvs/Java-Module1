package assignment1;

import java.util.Scanner;

public class ScannerExample {
public static void main(String[] args) {
	Scanner s1=new Scanner(System.in);
	Scanner s2=new Scanner(System.in);

	System.out.println("Name");
	String name=s1.nextLine();
	System.out.println("age:");
	int age=s2.nextInt();
	System.out.println("Address");
	String address=s1.nextLine();
	System.out.println(name+" "+age+" "+address);
}
}
