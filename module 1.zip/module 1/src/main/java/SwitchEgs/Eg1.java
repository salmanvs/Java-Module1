package SwitchEgs;

public class Eg1 {
	public static void main(String[] args) {
		int num=3;
		switch(num){
		case 0:
			System.out.println("number is zero");
		break;
		case 1:
			System.out.println("number is 1");
			break;
		case 2:
			System.out.println("number is 2");
			break;
			default:
				System.out.println(num);
		}
	}
}