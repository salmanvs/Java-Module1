package assignments3;

public class Grandchild extends Child {
	void ability() {
		System.out.println("He can dance");
	}
	
		

}
