package assignments3;

public class TestVehicle {
	public static void main(String[] args) {
			Car c=new Car();
			c.showVehicle();
			Motorcycle m=new Motorcycle();
			m.showVehicle();

	}
}
