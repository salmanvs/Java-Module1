package assignments3;

public class Vehicle {
	void showVehicle(){
		System.out.println("I am in a vehicle");
	}

}
