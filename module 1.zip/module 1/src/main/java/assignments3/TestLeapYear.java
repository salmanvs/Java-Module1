package assignments3;

import java.util.Scanner;

public class TestLeapYear {
	public static void main(String[] args) {
		System.out.println("LEAP YEAR DECIDER");
		System.out.println();
		System.out.print("Enter Year : ");
		
		Scanner s = new Scanner(System.in);
		int input= Integer.parseInt(s.nextLine()); //doubt
		LeapYearDecider year = new LeapYearDecider();
		System.out.println(input +" is a leap year ? "+year.isLeapYear(input));

	}

}
