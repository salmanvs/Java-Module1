package assignments3;

public class TestAbility {
	public static void main(String[] args) {
		Grandchild g=new Grandchild();
		g.ability();
	}

}
