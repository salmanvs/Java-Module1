package assignments3;

public class Car extends Vehicle{
	void showVehicle() {
		System.out.println("I am in a car");
	}

}
