package assignments3;

public class Motorcycle extends Vehicle {
	void showVehicle() {
		System.out.println("I am in a motorcycle");
	}

}
