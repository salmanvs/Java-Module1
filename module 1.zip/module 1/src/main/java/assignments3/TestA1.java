package assignments3;

public class TestA1 {
	public static void main(String[] args) {
		System.out.println("Vehicle Details");
		System.out.println("...............");
		System.out.println();
		A1 car=new A1(4, 5);
		System.out.print("car ");
		car.show();
		System.out.println();
		System.out.println();
		A1 bike=new A1(2, 2);
		System.out.print("bike ");
		bike.show();
	}

}
