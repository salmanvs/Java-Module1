package assignments3;

public class Factorial {
	
}
