package assignments3;

public class Parent {
	void ability() { 
		System.out.println("He can sing");
	}

}
