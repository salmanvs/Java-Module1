package assignments3;

public class A1 {
	int wheels;
	int seats;
	A1 (int wheels,int seats){
		this.wheels=wheels;
		this.seats=seats;
	}void show(){
		System.out.println("details");
		System.out.println("~~~~~~~~~~~");
		System.out.println();
		System.out.println("It has "+seats+" seats");
		System.out.println("It has "+wheels+" wheels");
	}

}
