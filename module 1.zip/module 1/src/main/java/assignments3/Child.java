package assignments3;

public class Child extends Parent {
	void ability() { 
		System.out.println("He can draw  ");
	}
		

}
