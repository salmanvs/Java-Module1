package breakexample;

public class Eg1 {
	public static void main(String[] args) {
		for(int i=1;i<=5;i++) {
			if(i==5) {
				break;
			}System.out.println(i);
		}
	}

}
