package regularexpression;

import java.util.regex.Pattern;

public class Charecterclass {
	public static void main(String[] args) {
		System.out.println(Pattern.matches("[a-z&&[def]]", "d"));
		System.out.println(Pattern.matches("[a-z]", "a"));
		System.out.println(Pattern.matches("[^abc]", "a"));
		System.out.println(Pattern.matches("[a-zA-Z]", "A"));
		System.out.println(Pattern.matches("[a-d[m-p]]", "m"));
		System.out.println(Pattern.matches("[a-z&&[^bc]]", "c"));
		System.out.println(Pattern.matches("[a-z&&[^m-p]]", "n"));

		System.out.println("Regex Quantifiers");
		
		
		System.out.println(Pattern.matches("[[a-z]{2}]", "salman"));
	}

}
