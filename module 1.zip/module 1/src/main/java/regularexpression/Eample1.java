package regularexpression;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Eample1 {
	public static void main(String[] args) {
		Pattern p=Pattern.compile("..s");
		Matcher m=p.matcher("aas");
		boolean b=m.matches();
		
		System.out.println(b);
		
		System.out.println(Pattern.matches("..s", "das"));
		
		System.out.println(Pattern.matches("...ss", "masss"));
	}

}
