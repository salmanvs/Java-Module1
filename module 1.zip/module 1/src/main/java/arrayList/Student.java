package arrayList;

public class Student {
	int id,rollno;
	String name;
	Student(String name, int id,int rollno){
		this.id=id;
		this.name=name;
		this.rollno=rollno;
	}
}