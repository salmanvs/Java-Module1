package arrayList;

import java.util.*;


public class TestStudent {
	public static void main(String[] args) {
		Student s1=new Student("dileep", 001, 12001);
		Student s2=new Student("mohanlal", 002, 12002);
		Student s3=new Student("jayaram", 003, 12003);
		Student s4=new Student("nivin", 004, 12004);
		
		ArrayList<Student> Stl=new ArrayList<Student>();
		Stl.add(s1);
		Stl.add(s2);
		Stl.add(s3);
		Stl.add(s4);
		
		Iterator itr=Stl.iterator();
		while(itr.hasNext()) {
			Student st=(Student)itr.next();
			System.out.println(st.id+" "+st.name+" "+st.rollno);
		}
	}

}
