package arrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class E1 {
	public static void main(String[] args) {
		ArrayList<String>list=new ArrayList<String>();
		list.add("kuttusan");
		list.add("dakini");
		list.add("luttappi");
		list.add("mayavi");
		
//		System.out.println(list);
//		
//		System.out.println();
		
//		Iterator itr=list.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
		
		
		
		for(String i:list) {
			System.out.println(i);
		}
		System.out.println();
		
		System.out.println("main member is "+list.get(2));
		 list.set(2, "rolex");
		 
		 System.out.println();
		 
		 for(String i:list) {
			 System.out.println(i);
		 }
		 System.out.println();
		 Collections.sort(list);
		 for(String i:list) {
			 System.out.println(i);
		 }
		 System.out.println();
		 ArrayList<Integer>list2=new ArrayList<Integer>();
		 list2.add(25);
		 list2.add(45);
		 list2.add(12);
		 list2.add(35);
		 
		 System.out.println(list2);
		 
		 for(Integer i:list2) {
			 System.out.println(i);
			 
		 }
		 System.out.println();
		 
		 Collections.sort(list2);
		 for(Integer i:list2) {
			 System.out.println(i);
		 }
	}

}
