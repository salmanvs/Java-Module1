package opertors;

public class Unary {
public static void main(String[] args) {
	int x=10,y=20;
	int z=-10;
	boolean a=true;
	System.out.println(x);//x=10
	System.out.println(x++);//x=x+1=>10=10+1(11)
	System.out.println(x);
	x++;
	System.out.println(x++);
	System.out.println(x);
	System.out.println(++y);
	System.out.println(y);
	++y;
	System.out.println(y);
	System.out.println(!a);
	System.out.println(~z);
}
}