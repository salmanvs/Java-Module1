package opertors;

public class example4 {
	public static void main(String[] args) {
		int a=10;
		int b=11;
		if(a>b) {
			System.out.println("yes");
		}
		else {
			System.out.println("no");
			
		}
	}

}
