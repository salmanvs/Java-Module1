package OOPs;

public class TestRectangle {
	public static void main(String[] args) {
		Rectangle r1=new Rectangle(),r2=new Rectangle();
		r1.insert(3, 2);
		r2.insert(7, 3);
		r1.toString();
		System.out.println(r1);
		r1.disply();
		r2.toString();
		System.out.println(r2);
		r2.disply();
	}

}
