package OOPs;

public class TestStudent1 {
	public static void main(String[] args) {
		Student1 s1=new Student1();
		s1.name="das";
		s1.id=21;
		System.out.println(s1.name+" "+s1.id);
		Student1 s2=new Student1();
		s2.name="ewd";
		s2.id=32;
		System.out.println(s2.name+" "+s2.id);
	}

}
