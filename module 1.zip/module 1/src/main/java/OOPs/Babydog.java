package OOPs;

public class Babydog extends Animal {
void sleep() {
	System.out.println("sleeping");
}
}
