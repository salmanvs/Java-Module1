package OOPs;

public class circle2 {
	double radius = 1.0;

	public circle2() {

	}

	public circle2(double radius) {

	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public double getarea() {
		return Math.PI * radius * radius;
	}

	public double getCircumference() {
		return 2 * Math.PI * radius;
	}

	@Override
	public String toString() {
		return "circle2 [radius=" + radius + "]";
	}

}