package OOPs;

public class Emplyoee {
	// creating instance variables/data members/fields
	String name;
	int employeeID;

	// declaration of display method to display object values
	void disply() {
		System.out.println(name + " " + employeeID);
	}

	// declare method insert to initialize values of employee class object
	void insert(String n, int id) {
		name = n;
		employeeID = id;
	}

	// method to print object values which converts object values to string
	@Override
	public String toString() {
		return "Emplyoee [name=" + name + ", employeeID=" + employeeID + "]";
	}

}
