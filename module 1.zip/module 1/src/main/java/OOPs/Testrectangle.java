package OOPs;

public class Testrectangle {
	public static void main(String[] args) {
		rectangle r=new rectangle();
		r.setLength(10);
		r.setWidth(5);
		
		System.out.println(r.getarea());
		System.out.println(r.getperimeter());
	}

}
