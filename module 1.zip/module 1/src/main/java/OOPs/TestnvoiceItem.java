package OOPs;

public class TestnvoiceItem {
	public static void main(String[] args) {
		InvoiceItem i=new InvoiceItem(1011, "pencil", 10, 5.0f);
		System.out.println(i);
		System.out.print("total price : ");
		System.out.println(i.gettotal()+" Rs");
	}

}
