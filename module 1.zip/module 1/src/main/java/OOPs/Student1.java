package OOPs;

public class Student1 {
	int id;
	String name;

}
