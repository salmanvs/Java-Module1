package OOPs;

public class Child1 extends Parent{
String name="Anu";
void disply()
{
	System.out.println(name);
}
}
