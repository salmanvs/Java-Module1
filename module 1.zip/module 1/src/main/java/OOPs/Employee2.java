package OOPs;

public class Employee2 {
float salary;
}
