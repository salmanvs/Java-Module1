package OOPs;


public class Bank {
	float getintrestrate() {
		return 0;}
	}

	class SBI extends Bank {
		float getintrestrate() {
			return 8;
		}
	}

	class AXIS extends Bank {
		float getintrestrate() {
			return 9;
		}
	}

	class PNB extends Bank {
		float getintrestrate() {
			return 7;
		}
	}




