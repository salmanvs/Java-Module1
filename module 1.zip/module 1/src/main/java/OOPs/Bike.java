package OOPs;

public class Bike extends Vehicle {
	public static void main(String[] args) {
		Bike b = new Bike();
		b.run();
	}

}