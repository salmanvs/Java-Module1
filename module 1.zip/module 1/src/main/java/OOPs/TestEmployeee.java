package OOPs;

public class TestEmployeee {
public static void main(String[] args) {
	Employeee e=new Employeee(10101, "vedikettu", "kochunni", 50000);
	System.out.println("name : "+e.getname());
	System.out.println("ID : "+e.getId());
	System.out.println("Salary : "+e.getSalary());
	System.out.println("Annual Salary : "+e.getannualsalary());
	System.out.println(e);
}
}
