package OOPs;

public class Bike2 extends Vehicle{
	void run() {
		System.out.println("bike is running safely");
	}

	public static void main(String[] args) {
		Bike2 b=new Bike2();
		b.run();
	}
}
