package OOPs;

public class Employee3 {
	float salary;
	void disply() {
		System.out.println(10000);
	}

}
