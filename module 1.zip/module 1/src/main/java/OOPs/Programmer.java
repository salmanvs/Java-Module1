package OOPs;

public class Programmer extends Employee2{
	int bonus;
public static void main(String[] args) {
	Programmer p1=new Programmer();
	p1.salary=1400000;
	p1.bonus=10000;
	System.out.println(p1.salary+" "+p1.bonus);
}
}
