package OOPs;

public class TestMultiplicacton {
	public static void main(String[] args) {
		new Multiplication().num(1);
	}

}
