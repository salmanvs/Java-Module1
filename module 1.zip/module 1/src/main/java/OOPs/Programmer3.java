package OOPs;

public class Programmer3 extends Employee3 {
	int bonus;
void display() {
	System.out.println(5000);
}
}