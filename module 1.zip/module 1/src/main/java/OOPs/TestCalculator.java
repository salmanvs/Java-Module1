package OOPs;

public class TestCalculator {
	public static void main(String[] args) {
		new Calculator().fact(5);
	}

}
