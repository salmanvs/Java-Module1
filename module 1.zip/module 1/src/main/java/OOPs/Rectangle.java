package OOPs;

public class Rectangle {
	int l;
	int b;
	void insert(int length,int bredth) {
		l=length;
		b=bredth;
	}void disply(){
		System.out.println("area ="+l*b);
		System.out.println("peremeter ="+2*(l+b));
	}
	@Override
	public String toString() {
		return "Rectangle [l=" + l + ", b=" + b + "]";
	}

}
