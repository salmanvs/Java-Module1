package OOPs;

public class Parent {
	int a=10;
	void display()
	{
		System.out.println(a);
	}
}
