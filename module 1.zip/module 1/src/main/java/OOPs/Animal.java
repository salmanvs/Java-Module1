package OOPs;

public class Animal {
	void eat() {
		System.out.println("eating");
	}

}
