package OOPs;

public class Multiplication {
	void num(int n) {
		int num=1;
		for(int i=1;i<=4;i++) {
			num=(num*i);
		}System.out.println("sum = "+num);
		
	}

}
