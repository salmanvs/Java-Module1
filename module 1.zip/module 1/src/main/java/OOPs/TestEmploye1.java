package OOPs;

public class TestEmploye1 {
	public static void main(String[] args) {
		new Employee1().disply();
		new Employee1().insert(10, "Anu", 12146879);
		Employee1 e=new Employee1();
		e.insert(1,"qwerty", 10000);
		Employee1 e1=new Employee1();
		e1.insert(2, "sdfg", 22220);
		e.disply();
		e1.disply();
		e.toString();
		System.out.println(e.toString());
		e1.toString();
		System.out.println(e);
		Employee1 e2=new Employee1(),e3=new Employee1();
		
	}

}
