package OOPs;

public class TestCircle2 {
	public static void main(String[] args) {
		circle2 c1=new circle2();
		c1.setRadius(5);
		System.out.println(c1.getRadius() + " " + c1.getarea() + " " + c1.getCircumference());
	}

}
