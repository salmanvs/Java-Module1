package OOPs;

public class Calculator {
	void fact(int i) {
		int fact=1;
		for(int x=1;x<=i;x++) {
			fact=fact*x;
		}System.out.println("factorial is "+fact);
	}

}
