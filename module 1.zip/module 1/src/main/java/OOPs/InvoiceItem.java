package OOPs;

public class InvoiceItem {
	int id;
	String description;
	int quantity;
	double unitprice;
	public InvoiceItem(int id,String description,int quantity,double unitprice) {
		this.id=id;
		this.description=description;
		this.quantity=quantity;
		this.unitprice=unitprice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(double unitprice) {
		this.unitprice = unitprice;
	}
	public int getId() {
		return id;
	}
	public String getDescription() {
		return description;
	}
	public double gettotal() {
		return unitprice*quantity;
	}
	@Override
	public String toString() {
		return "InvoiceItem [id=" + id + ", description=" + description + ", quantity=" + quantity + ", unitprice="
				+ unitprice + "]";
	}

}
