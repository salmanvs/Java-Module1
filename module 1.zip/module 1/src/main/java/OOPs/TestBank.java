package OOPs;


public class TestBank {
	public static void main(String[] args) {
		SBI s=new SBI();
		AXIS a=new AXIS();
		PNB p=new PNB();
		System.out.println(s.getintrestrate());
		System.out.println(a.getintrestrate());
		System.out.println(p.getintrestrate());
		}
	

}
