package OOPs;

public class TestProgrammer {
	public static void main(String[] args) {
		Programmer3 p=new Programmer3();
		p.disply();
		p.display();
		
	}

}
