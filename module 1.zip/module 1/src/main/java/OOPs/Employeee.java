package OOPs;

public class Employeee {
	int id;
	String firstname;
	String lastname;
	int salary;

	public Employeee(int id, String firstname, String lastname, int salary) {
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}
	public String getname() {
		return firstname+" "+lastname;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getannualsalary() {
		return 12*salary;
	}

	@Override
	public String toString() {
		return "Employeee [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", salary=" + salary
				+ "]";
	}
    
}
