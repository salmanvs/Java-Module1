package OOPs;

public class ParentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Parent p1=new Parent();
p1.display();
Child1 c1=new Child1();
c1.display();
c1.disply();

	}

}
