package OOPs;

public class TestAnimal {
	public static void main(String[] args) {
		Dog d=new Dog();
		d.bark();
		d.eat();
		System.out.println();
		Babydog b=new Babydog();
		b.sleep();
		
		b.eat();
		
	}

}
