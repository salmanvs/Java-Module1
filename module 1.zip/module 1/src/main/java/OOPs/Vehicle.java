package OOPs;

public class Vehicle {
	void run() {
		System.out.println("vehicle is running");
	}

}
