package ifexamples;

public class Eg3 {
	public static void main(String[] args) {
		int number=11;
		String output=(number%2==0)?"even number":"odd number";
		System.out.println(output);
	}

}
