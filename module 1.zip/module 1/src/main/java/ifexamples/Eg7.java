package ifexamples;

public class Eg7 {

}
