package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import loopEg.whileloopEg1;

public class Eg1 {
	public static void main(String[] args) {
		ArrayList<Integer>list1=new ArrayList<Integer>();
		list1.add(10);
		list1.add(20);
		System.out.println(list1);
		
		System.out.println();
		
		for(int i:list1) {
			System.out.println(i);
			
		}
		System.out.println();
		
		
		Iterator it=list1.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
			
		}
		System.out.println();
		ArrayList<String>list2=new ArrayList<String>();
		list2.add("arun");
		list2.add("kiran");
		System.out.println(list2);
		System.out.println();
		for(String i:list2) {
			System.out.println(i);
			
			
	}
		System.out.println();
		Iterator its=list2.iterator();
		while (its.hasNext()) {
			System.out.println(its.next());
		
		}	}
}
