package stringex;

public class String1 {
public static void main(String[] args) {
	String str1="Anu";//literal
	String str3="Anu";
	String str2=new String("Arun");//new 
	System.out.println(str1);
	str1=str1.concat("Ram");
	System.out.println(str1);

	System.out.println(str1);
	System.out.println(str1.equals(str2));
	String s1="java";
	String s2="Java";
	String s3=new String("java");
	System.out.println(s1.equals(s2));
	System.out.println(s1.equals(s3));//compares the content
	System.out.println(s2.equals(s3));
	System.out.println(s1.equalsIgnoreCase(s2));
	System.out.println(s1.compareTo(s2));



}
}
