package superkeyword;

public interface Print {
	void print();

}
