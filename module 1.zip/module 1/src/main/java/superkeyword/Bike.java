package superkeyword;

public final class Bike {
	 int speedlimit=90;
	final void limit(int speedlimit) {
		this.speedlimit=speedlimit;
		System.out.println(speedlimit );
	}

}
