package superkeyword;

//public class Bike1 extends Bike{
//	void limit() {
//		System.out.println(110);
//	}
//	public static void main(String[] args) {
//		Bike b=new Bike();
//		b.limit(100);
//	}
//
//}
