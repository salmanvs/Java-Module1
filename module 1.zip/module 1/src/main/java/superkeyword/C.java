package superkeyword;

public class C implements A,B{

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

}
