package superkeyword;

public class Student1 {
	protected String name= "das";
	protected int id=19001;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Student1 [name=" + name + ", id=" + id + "]";
	}

}
