package superkeyword;

public class Student extends College{
	
	int id;
	String name,course;
	String collegename;
	void display()
	{
		System.out.println("Id "+id+" Name "+name+" Course "+course);
		System.out.println(collegename);
		System.out.println(super.collegename);
		super.change();
		
	}
	public Student(int id, String name, String course,String collegename) {
		super(collegename);
		this.id = id;
		this.name = name;
		this.course = course;
	}
	

}
