package superkeyword;

public class Dog extends Animal{
	final int value=500;
	void changeValue()
	{
		//value=1000;
		System.out.println(value);
	}
}
	
//	@Override
//	void display() {
//		// TODO Auto-generated method stub
//		super.display();
//	}
	
//public Dog() {
//	super();
//	//super(8);
//
//	System.out.println("Child constructor");
//		// TODO Auto-generated constructor stub
//	}

//	public Dog(int a) {
//		super(a);
//		// TODO Auto-generated constructor stub
//	}

//public static void main(String[] args) {
//	Animal d1=new Dog();
//	d1.changeValue();
//}
//
////public Dog(int a) {
////	super(a);
////	// TODO Auto-generated constructor stub
////}
//}
