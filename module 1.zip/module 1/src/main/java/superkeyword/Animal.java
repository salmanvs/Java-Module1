package superkeyword;

public  class Animal {

	public Animal() {
		System.out.println("Super class constructor");
	}
	
	final void display()
	{
		System.out.println("parent method");
	}
	final void display(int a)
	{
		System.out.println("parent method");
	}
	
	public Animal(int a) {
		System.out.println("Super class constructor "
				+a);
	}
}
