package superkeyword;

public class A1 implements Print{
	public void print() {
		System.out.println("hai");
	}
public static void main(String[] args) {
	Employee e1=new Employee();
//	System.out.println(e1.name);
//	e1.s
}
}
