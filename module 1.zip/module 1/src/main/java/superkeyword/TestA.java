package superkeyword;

public class TestA implements A{

	@Override
	public void print() {
System.out.println("ekliol");	

	}
	public static void main(String[] args) {
		A a=new TestA();
		TestA b=new TestA();
		b.print();
		System.out.println(b.i);
	}

}
