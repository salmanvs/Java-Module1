package superkeyword;

public interface A {
	
	 void print();

	 static int i=19;
}
