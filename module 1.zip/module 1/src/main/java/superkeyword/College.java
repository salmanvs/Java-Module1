package superkeyword;

public class College {
	String collegename;

	public College(String collegename) {
		super();
		this.collegename = collegename;
	}

	void change()
	{
		System.out.println("Changed");
	}
}
