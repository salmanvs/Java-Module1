package superkeyword;

public interface B {
	 void print();

}
