package superkeyword;

public class TestStudent1 {
	public static void main(String[] args) {
		Student1 s=new Student1();
		s.setName("das");
		System.out.println(s.getName());
	}

}
