package basics;

public class Simple {
	
	public static void main(String arg[]) {
		
		int a=10;
		float b=10.5f;
		
		System.out.println("hello world");
		System.out.println("Salman");//ln used for new line
		System.out.print("Hello");
		System.out.println("Hai");//"" string
		System.out.println("h");
		System.out.print(10);//int 
		System.out.println(10.6);//float
		System.out.println(true);//boolean
		System.out.println('A');//char
		System.out.println(a);
	}

}
